

jQuery(document).ready(function(){
    jQuery('.banner-area').slick({
        autoplay: true,
        autoplaySpeed: 3000,
        prevArrow: '<button type="button" class="slick-left"><i class="fa-solid fa-arrow-left"></i></button>',
        nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-arrow-right"></i></button>'
     
    });

    jQuery('.testimonial').slick({
        dots: true,
        autoplay: true,
        slidesToShow: 2,
        autoplaySpeed: 3000,
        responsive: [
            {
              breakpoint: 770,
              settings: {
                slidesToShow: 1,
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
              }
            }
          ]

       
    });
    $('#navigation-menu').slicknav();
});

(function($){

  jQuery(document).ready(function(){

      jQuery(window).scroll(function(){

          var sumonIt = jQuery(window).scrollTop();

          if ( sumonIt > 100 ){
              jQuery('.scroll-to-top').fadeIn();
          }else{
              jQuery('.scroll-to-top').fadeOut();
          }
      })

      jQuery('.scroll-to-top').on('click', function(){

          jQuery('html, body').animate({'scrollTop' : 0}, 500);

      })

  })

  jQuery(document).ready(function(){

    jQuery(window).on('scroll', function(){
 
       if(jQuery(this).scrollTop() > 100){
           jQuery('.header-area').addClass('sticky');
       }else{
           jQuery('.header-area').removeClass('sticky');
       }
 
    });
 });

}(jQuery));


